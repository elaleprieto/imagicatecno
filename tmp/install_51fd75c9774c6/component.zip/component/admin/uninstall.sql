DROP TABLE IF EXISTS `#__kaltura_config`;
