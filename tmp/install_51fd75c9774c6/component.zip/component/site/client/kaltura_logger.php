<?php
class KalturaLogger implements IKalturaLogger
{
	public function __construct()
	{
	}

	public function log($str) 
	{
		// echo $str . "<br/>\n";
	}
}
?>
