<?php
// The general information at the top of each file
/**
* @version              $Id$
* @package              Joomla
* @copyright    Copyright (C) 2005 - 2009 Open Source Matters, Inc. All rights reserved.
* @license              GNU General Public License, see LICENSE.php
*/

  require_once(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_kalturavideo'.DS.'lib.php');
  
// No direct access allowed to this file
defined( '_JEXEC' ) or die( 'Restricted access' );
 
// Import Joomla! Plugin library file
jimport('joomla.plugin.plugin');
 
//The Content plugin Loadmodule
class plgContentKaltura extends JPlugin
{

		/**
		 * Constructor
		 *
		 * For php4 compatability we must not use the __constructor as a constructor for plugins
		 * because func_get_args ( void ) returns a copy of all passed arguments NOT references.
		 * This causes problems with cross-referencing necessary for the observer design pattern.
		 *
		 * @param object $subject The object to observe
		 * @param object $params  The object that holds the plugin parameters
		 * @since 1.5
		 */
		 
        function plgContentKaltura( &$subject, $params )
        {
                parent::__construct( $subject, $params );
		            global $mainframe;

		            $doc 		=& JFactory::getDocument();

		            $doc->addStyleSheet( JURI::Base() . 'components/com_kalturavideo/css/kaltura_rt.css', 'text/css', null, array() );
          	    $doc->addScript(JURI::Base() . 'components/com_kalturavideo/js/swfobject.js');

                $js = " 
                var kaltura_load_funcs= new Array();
                window.addEvent('domready', KalturaLoad);
                function KalturaLoad() 
                {
                    for (i=0; i < kaltura_load_funcs.length; i++)
                    {
                       eval(kaltura_load_funcs[i]);
                    }
                }
                ";

		            $doc->addScriptDeclaration($js);
               
        }

		  function onBeforeDisplayContent( &$article, &$params, $limitstart )
        {
                global $mainframe;
                //add your plugin codes here
            		JPlugin::loadLanguage('plg_content_kaltura', JPATH_ADMINISTRATOR );		
               
                $article->text = kaltura_replace_tags($article->text, $article->created_by);
                return '';
                //return a string value. Returned value from this event will be displayed in a placeholder. 
                // Most templates display this placeholder after the article separator. 
        }
    
}
?>